package com.foodSystem.Api_Fateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiFatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiFatewayApplication.class, args);
	}

}
