package com.foodSystem.Api_Fateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiFatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
